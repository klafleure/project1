Kaitria LaFleure
I created a web application for a fake business called Booking Agency. It is similar to Airbnb. It is a web appplication that allows customers to book vacations.
You can create an account on the Create Account page. You can also view a gallery of vacation spots and collect your favorite bookings on the Favorite screen.
I used HTML, CSS, JavaScript, bootstrap, & GitHub.
Three ideas for future improvement
    Add a page for reviews
    Add a page to submit questions
    Add a page to search bookings near you
    Figure out how to actually add a favorite button next to the vacation spots and add those to the favorites page